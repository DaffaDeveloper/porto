module.exports = {
  tokens: "8395857624:AAF4RjBwkAUA262_n9pgmUKHZ90Wm7S-xOk",  // Ubah Jadi Token Bot Mu !!!
  owner: "8149953533", // Ubah Jadi Id Mu !!!
  port: "4102", // Ubah Jadi Port Panel Mu !!!
  ipvps: "139.59.5.72" // Ubah Jadi Ip Vps Mu !!!
};